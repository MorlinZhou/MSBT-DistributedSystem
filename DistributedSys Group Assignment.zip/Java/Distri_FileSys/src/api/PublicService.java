package api;

public interface PublicService {
    String sayHello(String name);
}
